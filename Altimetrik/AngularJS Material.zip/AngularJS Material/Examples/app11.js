var myApp = angular.module("myApp",[]);
myApp.controller("directiveController", function($scope){

});


  



