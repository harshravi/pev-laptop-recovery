var myApp = angular.module("myApp",[]);

myApp.controller("formController", function($scope){
	$scope.myForm = {};
	$scope.myForm.name = "Lakshman";
	$scope.myForm.pin = "000000";
});


  



