var myApp = angular.module("myApp",[]);
myApp.controller("dateController",function($scope){
  $scope.today = new Date();
});



