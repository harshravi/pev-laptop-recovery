var myApp = angular.module("myApp",[]);
myApp.controller("personController",function($scope){
  $scope.person = {
		name : 'Lakshman',
		email : 'acme@acmecorp.com'
	};

});


