var myApp = angular.module("myApp",['app.directives.datetime']);
myApp.controller("directiveController",function($scope){

 });

  



